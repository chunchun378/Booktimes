package com.e.booktimesloat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AddAddress extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_address);
    }
}