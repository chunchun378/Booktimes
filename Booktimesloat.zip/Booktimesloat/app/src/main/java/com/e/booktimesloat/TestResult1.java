package com.e.booktimesloat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TestResult1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_result1);
    }
}